<?php


// Get the ID of the currently logged-in user

// Check if the 'user_id' parameter is set in the URL.
//var_dump($_GET); // Debugging line to check the contents of $_GET

if (isset($_GET['user_id'])) {
    $user_id = intval($_GET['user_id']); // Sanitize the input as an integer.
    $user = new WP_User($user_id);

    if ($user->exists()) {
        $user_name = $user->display_name; // Get the user's name.
        $user_email = $user->user_email;    // Get the user's email.
    } else {
        // User with the specified ID does not exist.
    }
} else {
    // 'user_id' parameter is not set in the URL.
}



$currentDateFormatted = date("F j, Y");

if (isset($_POST['upload_file'])) {
    $file = $_FILES['file_to_upload'];

    // Check if the file was uploaded successfully.
    if ($file['error'] === 0) {
        // Get the file data.
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];

        // Define the upload directory within the media library.
        $upload_dir = wp_upload_dir();
        
        $upload_path = $upload_dir['path'] . '/' . $file_name;

        // Move the uploaded file to the media library.
        if (move_uploaded_file($file_tmp, $upload_path)) {
            // Insert data into the media library.
            $file_type = wp_check_filetype($file_name, null);
            $attachment = array(
                'guid'           => $upload_dir['url'] . '/' . basename($upload_path),
                'post_mime_type' => $file_type['type'],
                'post_title'     => sanitize_file_name(pathinfo($file_name, PATHINFO_FILENAME)),
                'post_content'   => '',
                'post_status'    => 'inherit',
            );

            $attachment_id = wp_insert_attachment($attachment, $upload_path);

            if (!is_wp_error($attachment_id)) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_path);
                wp_update_attachment_metadata($attachment_id, $attachment_data);

                // You can now use $attachment_id to reference the uploaded file in the media library.
                
                // Assuming you have an 'id' to identify the record in your custom table.
               // $record_id = $_POST['record_id'];

                // Update the custom table with the attachment ID.
                global $wpdb;
                $table_name = $wpdb->prefix . 'usermember';

                $updated_data = array(
                    'invoices' => $upload_dir['subdir']. '/' . $file_name,
                );

                $where = array('user_id' => $user_id);

                $wpdb->update($table_name, $updated_data, $where);

                // Add success handling here.
            } else {
                // Handle the attachment creation error.
            }
        } else {
            // Handle the file upload error.
        }
    }
}



?>

<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
.invoice-title h2,
.invoice-title h3 {
    display: inline-block;
}

.table>tbody>tr>.no-line {
    border-top: none;
}

.table>thead>tr>.no-line {
    border-bottom: none;
}

.table>tbody>tr>.thick-line {
    border-top: 2px solid;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="invoice-title">
                <h2>User Invoice Details </h2>
            </div>
            <hr>
            <div class="row">
                <div class="col-xs-6">
                    <address><strong>Billed
                            To:</strong><br><?php echo esc_html($user_name); ?><br><?php echo esc_html($user_email); ?>
                    </address>
                </div>
                <div class="col-xs-6 text-right">
                    <address><strong>Invoice Date:</strong><br><?php echo $currentDateFormatted; ?>
                    </address>
                </div>
            </div>

        </div>
    </div>
    <div class="container">
        <div class="row">
            <!-- ... Your existing content ... -->
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><strong>Upload Invoices Pdf </strong></h3>
                    </div>
                    <div class="panel-body">
                        <form method="post" enctype="multipart/form-data">
                            <input type="file" name="file_to_upload" id="file_to_upload"><br>
                            <input type="submit" name="upload_file" value="Upload File">
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>