<?php

/*
Plugin Name: infoicon user list
Description: This plugin retrieves and displays a list of all default WordPress users in the admin dashboard.
Version: 1.0.0
Author: Your Name
*/
define( 'INFO_VERSION', '1.0.0' );
define( 'INFO_VERSION__MINIMUM_WP_VERSION', '5.5' );
define( 'INFO_VERSION_PLUGIN_NAME', 'infoicon user list');
define( 'INFO_VERSION__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'INFO_VERSION_BASE_URL', plugin_dir_url( __FILE__ ) );

// Hook to register the activation and deactivation functions
register_activation_hook(__FILE__, 'info_icon_activate');
register_deactivation_hook(__FILE__, 'info_icon_deactivate');

require_once(INFO_VERSION__PLUGIN_DIR . 'function.php' );


function info_icon_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'usermember';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        user_email varchar(255) NOT NULL,
        status varchar(255) DEFAULT '0',
        payment_id varchar(255) DEFAULT '0',
        invoices varchar(255) DEFAULT '0',
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Insert user data into the table with default values
    $args = array(
        'role__in' => array('subscriber', 'contributor', 'author', 'editor'),
    );

    $users = get_users($args);

    foreach ($users as $user) {
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user->ID,
                'user_email' => $user->user_email,
            )
        );
    }
 
}

function info_icon_deactivate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'usermember';
    $sql = "DROP TABLE $table_name";
    $wpdb->query($sql);
}

// Rest of your code...

// Add a menu to the admin dashboard
add_action('admin_menu', 'info_icon_admin_menu');

function info_icon_admin_menu() {
    // Add a top-level menu page
    add_menu_page(
        'InfoIcon User List',    // Page title
        'InfoIcon User List',    // Menu title
        'manage_options',        // Capability required to access this menu
        'info_icon_user_list',   // Menu slug
        'info_icon_user_list_page' // Callback function to display the page content
    );
}





function info_icon_user_list_page() {

    $action=$_GET['action']?$_GET['action']:'';
    if($action==='detail'){
        include('send_invoice.php');   
    }else if($action==='send'){
        include('invoices.php');   
    }else{ 
        include('user_list.php');
    }
   
}



?>