<?php
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class Custom_List_Table extends WP_List_Table {
    public function __construct() {
        parent::__construct(array(
            'singular' => 'custom_item',
            'plural'   => 'custom_items',
            'ajax'     => false
        ));
    }

    public function prepare_items() {
       global $wpdb;
 $table_name = $wpdb->prefix . 'usermember'; // Replace with the actual table name
    $query = "SELECT * FROM $table_name";
    $data = $wpdb->get_results($query, ARRAY_A);

    $columns = $this->get_columns();
    $sortable = $this->get_sortable_columns();

    $this->_column_headers = array($columns, array(), $sortable);

    $this->items = $data;
    }

    public function get_columns() {
        return array(
            'cb'              => '<input type="checkbox" />',
            'id'              => 'Id',
            'user_id'         => 'User Id',
            'payment_id'         => 'Payment Id',
            'user_email'           => 'Email',
            'Payment Amount'  => 'Payment Amount',
            'Payment Date'        => 'Payment Date',
        );
    }





public function column_default($item, $column_name) {
    
    if ($column_name === 'invoices') {
        $user_id = $item['user_id']; // Assuming the user's ID is stored in $item['ID']
       
        
        return $item[$column_name] . $this->row_actions($actions);
    } else {
        return $item[$column_name];
    }
}


    public function column_cb($item) {
        return '<input type="checkbox" name="custom_item[]" value="' . $item['ID'] . '" />';
    }

    public function get_sortable_columns() {
        return array(
            'id' => array('id', false),
             'user_id' => array('user_id', false),
              'user_email' => array('user_email', false),
              'status' => array('status', false),
            
        );
    }

    public function no_items() {
        echo 'No custom items found.';
    }
}

$custom_list_table = new Custom_List_Table();
$custom_list_table->prepare_items();
?>

<div class="wrap">
    <h2>User Payment details</h2>
    <form method="post">
        <?php
        $custom_list_table->display();
        ?>
    </form>
</div>